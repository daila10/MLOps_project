"""
This is a boilerplate pipeline 'data_engineering'
generated using Kedro 0.18.8
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
