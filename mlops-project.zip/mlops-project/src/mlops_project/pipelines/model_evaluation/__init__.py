"""
This is a boilerplate pipeline 'model_evaluation'
generated using Kedro 0.18.8
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
